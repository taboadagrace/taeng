$(document).ready(function(){
    $("button.login").click(function(){
        var username = $('#username').val();
        var password = $('#password').val();
        if(username == 'admin' && password == 'pass')
        {
            alert("Login Successful");
            localStorage.setItem('username','admin');
            localStorage.setItem('password','pass');
            window.location.href = "../HMDIY/Home.html";
        }else
        {
            alert("Username or Password are invalid!");
        }
    });

    $("li a#logout").click(function(){
        localStorage.clear();
        window.location.href = "../HMDIY/index.html";
    });

    var title = jQuery(this).attr('title');
    if(title === 'HMDIY-Home'){
        if(localStorage.length === 0){
            window.location.href = "../HMDIY/index.html";
        }
    }
});

function myFunction() {
  var input = document.getElementById("myInput");
  var filter = input.value.toLowerCase();
  var nodes = document.getElementsByClassName('row');

  for (i = 0; i < nodes.length; i++) {
    if (nodes[i].innerText.toLowerCase().includes(filter)) {
      nodes[i].style.display = "block";
    } else {
      nodes[i].style.display = "none";
    }
  }
}